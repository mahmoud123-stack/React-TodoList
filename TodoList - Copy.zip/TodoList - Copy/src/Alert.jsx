import React, { useState } from 'react'
import "./index.css";

export default function Alert({ active }) {

  return (
    
  )
}